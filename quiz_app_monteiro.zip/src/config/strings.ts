export const ENTRY_QUIZ_REFRI = [
  'entry.1638012119', // name
  'entry.2021544456', // question1
  'entry.653478899', // pts1
  'entry.850921029', // question2
  'entry.697665991', // pts2
  'entry.1518350475', // question3
  'entry.1421657240', // pts3
  'entry.1138974000', // question4
  'entry.458962466', // pts4
  'entry.2030913447', // question5
  'entry.928913573', // pts5
  'entry.529638290', // question6
  'entry.631853250', // pts6
  'entry.1331623558', // question7
  'entry.2040055134', // pts7
  'entry.1990341237', // question8
  'entry.909714284', // pts8
  'entry.1973319762', // question9
  'entry.305597890', // pts9
  'entry.1049439953', // question10
  'entry.1175156165', // pts10
  'entry.1718993316', // score
  'entry.2137797900', // tempo
]

export const ENTRY_QUIZ_ELETRIC = [
  'entry.1638012119', // name
  'entry.2021544456', // question1
  'entry.653478899', // pts1
  'entry.850921029', // question2
  'entry.697665991', // pts2
  'entry.1518350475', // question3
  'entry.1421657240', // pts3
  'entry.1138974000', // question4
  'entry.458962466', // pts4
  'entry.2030913447', // question5
  'entry.928913573', // pts5
  'entry.529638290', // question6
  'entry.631853250', // pts6
  'entry.1331623558', // question7
  'entry.2040055134', // pts7
  'entry.1990341237', // question8
  'entry.909714284', // pts8
  'entry.1973319762', // question9
  'entry.305597890', // pts9
  'entry.1049439953', // question10
  'entry.1175156165', // pts10
  'entry.1529320736', // question11
  'entry.1267410845', // pts11
  'entry.2129631756', // question12
  'entry.1648727873', // pts12
  'entry.733190288', // question13
  'entry.27839060', // pts13
  'entry.256056856', // question14
  'entry.1976764676', // pts14
  'entry.1187759332', // question15
  'entry.474747989', // pts15
  'entry.239977490', // question16
  'entry.2111040446', // pts16
  'entry.572104257', // question17
  'entry.1773724353', // pts17
  'entry.1169559210', // score
  'entry.1500697977', // tempo
]

export const FORM_URL_REFRI =
  'https://docs.google.com/forms/u/0/d/e/1FAIpQLSdCcj8aTQCntefys22tAj7veUQlGHQWFB7k8-K79tYOgcDybw/formResponse'

export const FORM_URL_ELETRIC =
  'https://docs.google.com/forms/u/0/d/e/1FAIpQLSd8396R3TYdakmy02iDrWaUUJ-AqPmIX_gck5zldxZ5W8j9gQ/formResponse'
